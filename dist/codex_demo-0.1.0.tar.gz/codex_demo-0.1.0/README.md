# Codex Demo

Starter project.

## Usage

```bash
python3 app.py                 # hello from codex demo
python3 app.py --shout         # HELLO FROM CODEX DEMO
python3 app.py --name James    # hello from codex demo, James
python3 app.py --name James --shout  # HELLO FROM CODEX DEMO, JAMES
```
# New test line

## Changelog

### v0.1.0
- Added GitHub Actions CI
- Added pre-commit hooks (Black + Ruff)
- Verified SSH & repo sync



## Install & Run (optional)

Install the CLI locally with pipx:

```bash
pipx install --force .
codex-demo --version
```
